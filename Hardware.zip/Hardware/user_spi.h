#ifndef __USER_SPI
#define __USER_SPI

#include "main.h"

#define SPI_Write_SS(x)								HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)(x))					
#define SPI_Write_SCK(x)							HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)(x))		
#define SPI_Write_MOSI(x)							HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)(x))
#define SPI_Read_MISO(void)						HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6)

void spi_init(void);
void spi_start(void);
void spi_stop(void);
uint8_t spi_swapbyte(uint8_t bytesend);
#endif
