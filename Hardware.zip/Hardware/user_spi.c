#include "user_spi.h"

void spi_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
  
	__HAL_RCC_GPIOA_CLK_ENABLE();
	/*
	����SPI GPIO Configuration
	PA4     ------> SPI_CS				�������
	PA5     ------> SPI_CLK				�������
	PA6     ------> SPI_DO				��������
	PA7     ------> SPI_DI				�������
	*/
	
	GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_7;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	GPIO_InitStruct.Pin = GPIO_PIN_6;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	SPI_Write_SS(1);
	SPI_Write_SCK(0);
}

void spi_start(void)
{
	SPI_Write_SS(0);						
}

void spi_stop(void)
{
	SPI_Write_SS(1);
}

//mode 0 ����һ���ֽ�����
uint8_t spi_swapbyte(uint8_t bytesend)
{
	uint8_t bytereceive = 0x00;
	
	for(int i = 0; i < 8; i++)
	{
		SPI_Write_MOSI(bytesend & (0x80 >> i));
		SPI_Write_SCK(1);
		if(SPI_Read_MISO() == 1)
			bytereceive |= (0x80 >> i);
		SPI_Write_SCK(0);
	}
	return bytereceive;
}

//mode 1
/****
uint8_t spi_swapbyte(uint8_t bytesend)
{
	uint8_t bytereceive = 0x00;
	
	for(int i = 0; i < 8; i++)
	{
		SPI_Write_SCK(1);
		SPI_Write_MOSI(bytesend & (0x80 >> i));
		SPI_Write_SCK(0);
		if(SPI_Read_MISO() == 1)
			bytereceive |= (0x80 >> i);
	}
	return bytereceive;
}
****/
